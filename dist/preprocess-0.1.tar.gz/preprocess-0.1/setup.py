from setuptools import setup
setup(
    name="preprocess",
    version="0.1",
    description="Este es un paquete de jemplo",
    author="Gerson Garcia",
    author_email="gerson.garciacampos@gmail.com",
    url="",
    packages=['preprocess', 'search'],
    scripts=[]
)